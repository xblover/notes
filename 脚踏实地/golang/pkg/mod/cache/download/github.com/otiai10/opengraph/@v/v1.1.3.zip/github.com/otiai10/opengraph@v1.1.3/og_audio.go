package opengraph

// OGAudio represents "og:audio" structure.
type OGAudio struct {
	URL  string
	SURL string
	Type string
}
