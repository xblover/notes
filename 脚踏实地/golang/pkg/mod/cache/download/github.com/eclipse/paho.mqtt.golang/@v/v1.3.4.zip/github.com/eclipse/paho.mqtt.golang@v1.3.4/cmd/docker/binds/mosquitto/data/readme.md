data
====

If you enable persistence in `mosquitto.conf` then the database will be written here.