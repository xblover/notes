// Package pkg ...
package pkg

import _ "fmt"
